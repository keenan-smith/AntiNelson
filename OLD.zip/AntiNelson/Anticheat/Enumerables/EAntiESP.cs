﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PointBlank.Anticheat.Enumerables
{
    internal enum EAntiESP
    {
        DISTANCE,
        WALL_BLOCK,
        CAMERA_VISIBILITY,
    }
}
